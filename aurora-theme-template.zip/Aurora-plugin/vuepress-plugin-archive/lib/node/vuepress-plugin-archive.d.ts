import type { Plugin } from '@vuepress/core';
export declare type ArchivePluginOptions = Record<never, never>;
export declare const ArchivePluginOptions: Plugin<ArchivePluginOptions>;
