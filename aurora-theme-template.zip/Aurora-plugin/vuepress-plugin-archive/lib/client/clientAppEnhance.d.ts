declare const _default: import("@vuepress/client").ClientAppEnhance;
export default _default;

