# serverUrl配置

1. 进入到[NeteaseCloudMusicApi仓库](https://github.com/Binaryify/NeteaseCloudMusicApi)

![image-20211122001209289](https://ooszy.cco.vin/img/blog-note/image-20211122001209289.png?x-oss-process=style/pictureProcess1)

当fork成功之后，你会在你自己的仓库中，看到此项目

![image-20211122001311599](https://ooszy.cco.vin/img/blog-note/image-20211122001311599.png?x-oss-process=style/pictureProcess1)



2. 进入[vercel的dashboard](https://vercel.com/dashboard)

![image-20211122001431005](https://ooszy.cco.vin/img/blog-note/image-20211122001431005.png?x-oss-process=style/pictureProcess1)



![image-20211122001640574](https://ooszy.cco.vin/img/blog-note/image-20211122001640574.png?x-oss-process=style/pictureProcess1)





![image-20211122001806989](https://ooszy.cco.vin/img/blog-note/image-20211122001806989.png?x-oss-process=style/pictureProcess1)



> 等待部署成功

![image-20211122001845643](https://ooszy.cco.vin/img/blog-note/image-20211122001845643.png?x-oss-process=style/pictureProcess1)

![image-20211122001946644](https://ooszy.cco.vin/img/blog-note/image-20211122001946644.png?x-oss-process=style/pictureProcess1)

![image-20211122002032565](https://ooszy.cco.vin/img/blog-note/image-20211122002032565.png?x-oss-process=style/pictureProcess1)





![image-20211122002306640](https://ooszy.cco.vin/img/blog-note/image-20211122002306640.png?x-oss-process=style/pictureProcess1)





你可以使用该api做很多的是，该api的详细使用[请查看](https://neteasecloudmusicapi.vercel.app/#/)