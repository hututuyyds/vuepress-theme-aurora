export let sites = [
    {
        //网站标题
        title: "qsyyke",

        //站点链接
        url: "https://blog.cco.vin",

        //站点logo
        logo: "https://ooszy.cco.vin/img/blog-public/avatar.jpg",

        //站点描述
        describe: "I do not follow,i lives is always all you want",
    },
]
