---
tag: [页面配置,关于页面,广告,友情链接,文章,标签,归档,相册]
---



# 页面配置

[关于页面](/config/page/about.md     )

[广告](/config/page/ad.md        )

[友情链接](/config/page/friendlink.md)

[心情页面](/config/page/mood.md      )
[文章页面](/config/page/page.md      )
[标签分类](/config/page/tag.md      )


[GitHub](https://github.com/qsyyke/vuepress-theme-ccds) 